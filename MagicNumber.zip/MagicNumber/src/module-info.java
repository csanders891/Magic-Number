/**
 * 
 */
/**
 * 
 */
module MagicNumber {
}